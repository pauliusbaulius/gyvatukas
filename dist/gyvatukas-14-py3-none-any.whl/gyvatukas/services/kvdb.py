# todo: jsonkvdb and sqlitekvdb based on diskcache which are simple key value stores for quick prototyping. or maybe base them on diskcache protocol.
