# get_random_secure_string(len, letters)
# get_uuid4
# get