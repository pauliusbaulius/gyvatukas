# todo: https://eu5.fusionsolar.huawei.com simple wrapper to extract stats, aka read-only wrapper.
#  Available libraries:
#  https://github.com/EnergieID/FusionSolar
#  https://github.com/jgriss/FusionSolarPy
#  https://github.com/guillaumeblanc/pyhfs
