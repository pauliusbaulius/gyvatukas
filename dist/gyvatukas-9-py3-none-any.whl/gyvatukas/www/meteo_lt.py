# TODO: MeteoLt client with rate limiting.
#  https://api.meteo.lt/
#  180 requests per minute aka 3 requests per second.
