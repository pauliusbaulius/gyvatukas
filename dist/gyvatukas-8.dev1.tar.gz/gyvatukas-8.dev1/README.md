# gyvatukas
collection of python utils and prototypes.
it is public, but i would not advise to use it for any serious business. is more of a util 
bundle and playground for new ideas.

anyways, see docs page for more info.

🚨 No changelog

🚩 Frequently changing API

🚨 Lack of tests

🤠 Only fun
